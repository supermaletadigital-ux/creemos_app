package com.creemos.santacruz.creemos

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

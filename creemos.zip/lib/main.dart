import 'package:flutter/material.dart';

void main() {
  runApp(const CreemosApp());
}

class CreemosApp extends StatelessWidget {
  const CreemosApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Creemos Santa Cruz',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Colors.white,
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.blue[900],
          titleTextStyle: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blue[800],
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          filled: true,
          fillColor: Colors.grey[100],
        ),
      ),
      home: const AcuerdoScreen(),
    );
  }
}

class AcuerdoScreen extends StatefulWidget {
  const AcuerdoScreen({super.key});

  @override
  State<AcuerdoScreen> createState() => _AcuerdoScreenState();
}

class _AcuerdoScreenState extends State<AcuerdoScreen> {
  bool _aceptado = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Acuerdo y Políticas - Creemos Santa Cruz'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Text(
                '¡Bienvenido a Creemos Santa Cruz!',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.blue[900]),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'Acepta los términos para continuar y unirte como militante verificado.',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 16),
            const Text(
              'Esta app está regulada por:\n'
              '• Constitución Política del Estado Plurinacional de Bolivia (CPE, Art. 21 intimidad, Art. 130 habeas data, Art. 14 libertad de elección).\n'
              '• Ley N° 164 General de Telecomunicaciones, Tecnologías de Información y Comunicación (Art. 13 derechos usuarios, Art. 26 contratos claros).\n'
              '• Ley N° 453 Derechos de Usuarios y Consumidores (Art. 8 info veraz y legible, prohibición de cláusulas abusivas).\n\n'
              'Consentimiento explícito para tratamiento de datos personales (nombre, CI, fecha nacimiento, teléfono, email, dirección, GPS, fotos de carnet/recibos/captura TSE).\n'
              'Falsedad en militancia o documentos → expulsión automática, copia de datos en lista interna de infiltrados (solo admins) para seguridad del partido.\n'
              'Actualizaciones legales cada 5 días vía backend – nueva aceptación requerida.\n'
              'Uso indebido desligado por aceptación expresa del usuario. Arbitraje en Santa Cruz bajo leyes bolivianas.',
              style: TextStyle(fontSize: 16, height: 1.5),
            ),
            const SizedBox(height: 32),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Checkbox(
                  value: _aceptado,
                  activeColor: Colors.blue[800],
                  onChanged: (value) {
                    setState(() {
                      _aceptado = value!;
                    });
                  },
                ),
                Expanded(
                  child: Text(
                    'Acepto los términos y políticas de uso (declaro bajo juramento ser militante de Creemos Santa Cruz y que toda falsedad será responsabilidad mía).',
                    style: TextStyle(fontSize: 16, color: _aceptado ? Colors.black : Colors.grey[800]),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 40),
            Center(
              child: ElevatedButton(
                onPressed: _aceptado
                    ? () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('¡Aceptado! Próximo: Registro / Login'),
                            backgroundColor: Colors.green,
                          ),
                        );
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const RegistroScreen()),
                        );
                      }
                    : null,
                child: const Text('Confirmar y Continuar', style: TextStyle(fontSize: 18)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class RegistroScreen extends StatefulWidget {
  const RegistroScreen({super.key});

  @override
  State<RegistroScreen> createState() => _RegistroScreenState();
}

class _RegistroScreenState extends State<RegistroScreen> {
  final _formKey = GlobalKey<FormState>();
  String _ci = '';
  String _telefono = '';
  String _email = '';
  String _direccion = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Registro de Militante - Creemos Santa Cruz'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Completa tus datos para verificación',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.blue[900]),
              ),
              const SizedBox(height: 24),
              TextFormField(
                decoration: const InputDecoration(
                  labelText: 'Carnet de Identidad (CI)',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.badge),
                ),
                keyboardType: TextInputType.number,
                validator: (value) => value == null || value.isEmpty ? 'Ingresa tu CI' : null,
                onSaved: (value) => _ci = value!,
              ),
              const SizedBox(height: 16),
              TextFormField(
                decoration: const InputDecoration(
                  labelText: 'Teléfono / WhatsApp',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.phone_android),
                ),
                keyboardType: TextInputType.phone,
                validator: (value) => value == null || value.isEmpty ? 'Ingresa tu teléfono' : null,
                onSaved: (value) => _telefono = value!,
              ),
              const SizedBox(height: 16),
              TextFormField(
                decoration: const InputDecoration(
                  labelText: 'Correo electrónico',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.email),
                ),
                keyboardType: TextInputType.emailAddress,
                validator: (value) {
                  if (value == null || value.isEmpty) return 'Ingresa tu email';
                  if (!value.contains('@')) return 'Email inválido';
                  return null;
                },
                onSaved: (value) => _email = value!,
              ),
              const SizedBox(height: 16),
              TextFormField(
                decoration: const InputDecoration(
                  labelText: 'Dirección (con referencia)',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.location_on),
                ),
                validator: (value) => value == null || value.isEmpty ? 'Ingresa tu dirección' : null,
                onSaved: (value) => _direccion = value!,
              ),
              const SizedBox(height: 32),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton.icon(
                    icon: const Icon(Icons.camera_alt),
                    label: const Text('Foto Carnet'),
                    onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Abrir cámara para foto de carnet frente/reverso')),
                    ),
                  ),
                  ElevatedButton.icon(
                    icon: const Icon(Icons.camera_alt),
                    label: const Text('Foto Recibo'),
                    onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Abrir cámara para recibo de luz/agua')),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                icon: const Icon(Icons.location_on),
                label: const Text('Capturar GPS'),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green[700]),
                onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('GPS capturado: Lat -16.5, Long -68.1')),
                ),
              ),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                icon: const Icon(Icons.photo_library),
                label: const Text('Captura TSE'),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.orange[800]),
                onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Abrir galería o cámara para captura TSE - OCR verificará militancia')),
                ),
              ),
              const SizedBox(height: 32),
              Center(
                child: ElevatedButton(
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      _formKey.currentState!.save();
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Registro enviado a verificación. Espera aprobación.'),
                          backgroundColor: Colors.green,
                        ),
                      );
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red[800],
                    padding: const EdgeInsets.symmetric(horizontal: 48, vertical: 20),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                  ),
                  child: const Text('Enviar Registro', style: TextStyle(fontSize: 18)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}